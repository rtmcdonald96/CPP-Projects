# 471Project
FTP Client Server for 471 Computer Communications

Kai Duty -> kdcptkai31@gmail.com
Riley Webber -> riley.webber@gmail.com
Madonna Lewis -> madonnalewis@csu.fullerton.com
Ernest Lin -> elin0303@csu.fullerton.edu
Ryan McDonald -> rtmcdonald96@csu.fullerton.edu


We used C++ for our programming language.
To run the program, navigate to 471Project/ and type `make all`.

Then run the server with the command `./runServer <valid port number>`
In order to simulate file transfer, move the `runClient` file to a different
directory. Then type the command `./runClient <server IP address> <same port number>`

At this point, type the desired commands into the running client:
[ls, get <filename>, put <filename>, quit]
